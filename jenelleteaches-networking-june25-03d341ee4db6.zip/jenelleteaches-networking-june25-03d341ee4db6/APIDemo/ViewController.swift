//
//  ViewController.swift
//  APIDemo
//
//  Created by Parrot on 2019-03-03.
//  Copyright © 2019 Parrot. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import WatchConnectivity

class ViewController: UIViewController, WCSessionDelegate {
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) {
        
    }
    
    func sessionDidDeactivate(_ session: WCSession) {
        
    }
    

    @IBOutlet weak var outputLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if (WCSession.isSupported()) {
            print("Yes it is!")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }

        
        // Do any additional setup after loading the view, typically from a nib.
        
        //let URL = "https://httpbin.org/get"
//        let URL = "https://randomuser.me/api/"
//
//        Alamofire.request(URL).responseJSON {
//
//            response in
//
//            // TODO: Put your code in here
//            // ------------------------------------------
//            // 1. Convert the API response to a JSON object
//
//            // -- check for errors
//            let apiData = response.result.value
//            if (apiData == nil) {
//                print("Error when getting API data")
//                return
//            }
//            // -- if no errors, then keep going
//
//            print(apiData)
//
//
//            // 2. Parse out the data you need (sunrise / sunset time)
//
//            // example2 - parse an array of dictionaries
//
//            // 2a. Convert the response to a JSON object
//            let jsonResponse = JSON(apiData)
//
//            print(jsonResponse)
        
            // Output the "title" of the item in position #2
//            self.outputLabel.text = item["title"].stringValue
            
//        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func sendDataPressed(_ sender: Any) {
        print("Button pressed")
        
        if (WCSession.default.isReachable) {
            
            let URL = "https://randomuser.me/api/"
            
            Alamofire.request(URL).responseJSON {
                
                response in
                
                
                let apiData = response.result.value
                if (apiData == nil) {
                    print("Error when getting API data")
                    return
                }
                
                print(apiData!)
                
                
                let jsonResponse = JSON(apiData!)
                
                print(jsonResponse)
                let data = jsonResponse["results"][0]["name"]["title"].stringValue
                let message = ["dat" : data]
                WCSession.default.sendMessage(message, replyHandler: nil)
        }
        
        } else {
            print("Cannot find watch")
        }
    
}
}

